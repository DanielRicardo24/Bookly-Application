link video penjelasan : https://drive.google.com/file/d/1v1DN7F70R20OlgJTJf9owY1r0mlQQHCf/view?usp=drive_link

a) Bookly adalah sebuah platform digital yang menyediakan berbagai macam eBook untuk semua kalangan pembaca. Dengan antarmuka yang user-friendly dan berbagai fitur canggih, Bookly bertujuan untuk menjadi solusi utama bagi para pecinta buku digital.

b) Daniel Ricardo Hadirahardja (00000071936)
Khalif Ziran Maulana (00000071749)
Muhammad Ravindra Mahesandra (00000072501)
Vinsensius Paulo Ryananda Virgiawan (00000073384)

c) 
- login dan sign up page
- searching pada page search
- update profile pada page profile (kamera untuk native fitur)
- admin untuk crud
- menampilkan dari detail buku (judul, penulis, synopsis dari database)
